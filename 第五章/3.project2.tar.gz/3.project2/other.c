/*************************************************************************
	> File Name: other.c
	> Author:wanminglei 
	> Mail:wanminglei@hotmail.com 
	> Created Time: Sun 01 Sep 2024 10:46:56 PM CST
 ************************************************************************/

#include<stdio.h>

int add(int a, int b) {
    printf("[other.c] this is add funtion : ");
    return a + b;
}
