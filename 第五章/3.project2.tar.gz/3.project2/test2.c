/*************************************************************************
	> File Name: test2.c
	> Author:wanminglei 
	> Mail:wanminglei@hotmail.com 
	> Created Time: Sun 01 Sep 2024 10:37:10 PM CST
 ************************************************************************/

#include<stdio.h>

int add(int a, int b) {
    return a + b;
}

int main () {
    int a = 123, b = 567;
    printf("a + b = %d\n", a + b);
    printf("add(%d, %d) = %d\n", a, b, add(a, b));
    return 0;
}
