/*************************************************************************
	> File Name: test1.c
	> Author:wanminglei 
	> Mail:wanminglei@hotmail.com 
	> Created Time: Sun 01 Sep 2024 10:32:51 PM CST
 ************************************************************************/

#include<stdio.h>

int main() {
    printf("hello world\n");
    return 0;
}
