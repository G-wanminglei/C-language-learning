/*************************************************************************
	> File Name: part2.c
	> Author:wanminglei 
	> Mail:wanminglei@hotmail.com 
	> Created Time: Mon 02 Sep 2024 09:42:03 PM CST
 ************************************************************************/


    printf("%d + %d = %d\n", a, b, a + b);
    printf("a = %d, b = %d\n", a, b);
    return 0;
}

