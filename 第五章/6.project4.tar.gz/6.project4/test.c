/*************************************************************************
	> File Name: test.c
	> Author:wanminglei 
	> Mail:wanminglei@hotmail.com 
	> Created Time: Mon 02 Sep 2024 09:34:33 PM CST
 ************************************************************************/

#include <stdio.h>
#include <def_a_b.c>

int main() {
    printf("a + b = %d\n", a + b);
    return 0;
}
