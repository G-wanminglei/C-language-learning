/*************************************************************************
	> File Name: def_a_b.c
	> Author:wanminglei 
	> Mail:wanminglei@hotmail.com 
	> Created Time: Mon 02 Sep 2024 09:36:47 PM CST
 ************************************************************************/

int a = 123, b = 567;
