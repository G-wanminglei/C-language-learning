/*************************************************************************
	> File Name: part1.c
	> Author:wanminglei 
	> Mail:wanminglei@hotmail.com 
	> Created Time: Mon 02 Sep 2024 09:39:02 PM CST
 ************************************************************************/

#include<stdio.h>

int main() {
    int a = 123, b = 567;
    #include "part2.c"
